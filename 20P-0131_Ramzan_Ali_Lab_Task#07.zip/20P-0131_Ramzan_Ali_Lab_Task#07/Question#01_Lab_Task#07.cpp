///////////////////////////////// Question # 01 /////////////////////////////////
#include<iostream>
using namespace std;
class Rectangle
{
	private:
		float length;
		float width;
	public:
		Rectangle();
		Rectangle(int,  int );
		Rectangle(int );
		~Rectangle();
		float area();
        void show();
        int sameArea(Rectangle);
        void setlength(float);
		void setwidth(float);
		
};
Rectangle::Rectangle(){                        
       length = 0;
       width = 0;
       cout<<length<<endl;
       cout<<width<<endl;
   }
Rectangle::Rectangle(int length, int width){                        
       length = 5;
       width = 2;
       cout<<length<<endl;
       cout<<width<<endl;
   }
Rectangle::Rectangle(int length ){                        
       length = 5;
       width = length;
       cout<<length<<endl;
       cout<<width<<endl;
   }
Rectangle::~Rectangle(){
    cout << endl;
	cout<<"Destructor is calling"<<endl;
}

void Rectangle::setlength(float len)
{
	length = len;
}
void Rectangle::setwidth(float wid)
{
	width = wid;
}

float Rectangle::area()
{
	return length * width;
}
void Rectangle::show()
{
	cout << "Length of Rectangle is : " <<length << endl;
    cout << "Width of Rectangle is : " << width <<endl;
}
int Rectangle::sameArea(Rectangle other)
{
	float areaf = length * width;
	float areas = other.length * other.width;
	if (areaf == areas)
		return 1;
	return 0;
}
int main(){

	Rectangle R1;
	Rectangle R2;
	R1.setlength(5);
	R1.setwidth(2.5);
	R2.setlength(5);
	R2.setwidth(18.9);
	cout << "Rectangle R1 : " << endl;
    cout << endl;
	R1.show();
	cout<< "Area of R1 is : " << R1.area()<< endl;
    cout << endl;
	cout << "Rectangle R2 : " << endl;
    cout << endl;
	R2.show();
	cout<< "Area of R2 is: " << R2.area()<< endl;
	if (R1.sameArea(R2))
		cout << "Rectangles have the same area\n";
	else
		cout << "Rectangles do not have the same area"<<endl;
	R1.setlength(15);
	R1.setwidth(6.3);
    cout << endl;
	cout << "R1 rectangle: "<<endl;
    cout << endl;
	R1.show();
	cout << "Area of R1 is : " << R1.area()<< endl;
    cout << endl;
	cout << "R2 rectangle: "<<endl;
    cout << endl;
	R2.show();
	cout<< "Area of R2 is : "<< R2.area()<< endl;
	if (R1.sameArea(R2))
		cout << "Rectangles have the same area"<<endl;
	else
		cout << "Rectangles do not have the same area"<<endl;
	return 0;
}

///////////////////////////////// Question # 01 /////////////////////////////////
