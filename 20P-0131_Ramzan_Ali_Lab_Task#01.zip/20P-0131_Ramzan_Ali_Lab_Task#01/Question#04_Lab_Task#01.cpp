///////////////////////////////////// Question #04 ///////////////////////////////////////

#include <iostream>

using namespace std;

int main()
{

    float cel;
    float far;

    cout << "Enter the Temperature in Celsius : " << endl;

    cin >> cel;

    far = (cel * 9.0) / 5.0 + 32;

    cout << "Given Temperature in Celsius is  : " << cel << endl;
    cout << "Converted temperature in Fahrenheit : " << far << endl;

    return 0;
}

///////////////////////////////////// Question #04 ///////////////////////////////////////
