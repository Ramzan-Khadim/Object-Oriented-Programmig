//////////////////////////////////// Question # 01 ////////////////////////////////////

#include <iostream>
using namespace std;

class Shapes
{

public:
    Shapes()
    {
        cout << "Shape constructor" << endl;
    }
    virtual void area() = 0;
    ~Shapes()
    {
        cout << "Shape distructor" << endl;
    }
};

class Two_D_Shapes : public Shapes
{

public:
    Two_D_Shapes() : Shapes()
    {
        cout << "2D_Shape constructor" << endl;
    }
    void area(){};
    ~Two_D_Shapes()
    {
        cout << "2D_Shape distructor" << endl;
    }
};

class Thr_D_Shapes : public Shapes
{

public:
    Thr_D_Shapes() : Shapes()
    {
        cout << "3D_Shape constructor" << endl;
    }
    void area(){};
    virtual void volume() = 0;
    ~Thr_D_Shapes()
    {
        cout << "3D_Shape distructor" << endl;
    }
};

class cirlce : public Two_D_Shapes
{

private:
    int radius;
    float pi = 3.14;

public:
    cirlce() : Two_D_Shapes()
    {
        cout << "Circle constructor" << endl;
    }
    void getData()
    {
        cout << "Please Enter Radius :: ";
        cin >> radius;
    }
    void area()
    {
        cout << "Area of cirlc is : " << pi * radius * radius << endl;
    };
    ~cirlce()
    {
        cout << "Circle distructor" << endl;
    }
};

class square : public Two_D_Shapes
{

private:
    int side;

public:
    square() : Two_D_Shapes()
    {
        cout << "Square constructor" << endl;
    }
    void getData()
    {
        cout << "Please Enter side :: ";
        cin >> side;
    }
    void area()
    {
        cout << "Area of Square is : " << side * side << endl;
    };
    ~square()
    {
        cout << "Square distructor" << endl;
    }
};

class cube : public Thr_D_Shapes
{

private:
    int length;
    int width;
    int height;

public:
    cube() : Thr_D_Shapes()
    {
        cout << "Cube constructor" << endl;
    }

    void getData()
    {
        cout << "Please Enter Length :: ";
        cin >> length;
        cout << "Please Enter width :: ";
        cin >> width;
        cout << "Please Enter height :: ";
        cin >> height;
    }
    void area()
    {
        cout << "Area of cube is : " << 6 * length * width << endl;
    };
    void volume()
    {
        cout << "Volume of Cube is : " << length * width * height << endl;
    };
    ~cube()
    {
        cout << "Cube distructor" << endl;
    }
};

class Pyramid : public Thr_D_Shapes
{

public:
    int base;
    int width;
    int height;
    int base_area;
    int para_base;
    int slant_height;

public:
    Pyramid() : Thr_D_Shapes()
    {
        cout << "Pyramid constructor" << endl;
    }
    void getData()
    {
        cout << "Please Enter Base :: ";
        cin >> base;
        cout << "Please Enter width :: ";
        cin >> width;
        cout << "Please Enter height :: ";
        cin >> height;
        cout << "Please Enter Base Area :: ";
        cin >> base_area;
        cout << "Please Enter para Base :: ";
        cin >> para_base;
        cout << "Please Enter slant Heigth :: ";
        cin >> slant_height;
    }
    void area()
    {
        cout << "Area of Pyramid is : " << base_area + 1 / 2 * para_base * slant_height << endl;
    };
    void volume()
    {
        cout << "Volume of Pyramid is : " << base * width * height / 3 << endl;
    };
    ~Pyramid()
    {
        cout << "Pyramid distructor" << endl;
    }
};

int main()
{
    Shapes *array = new Two_D_Shapes;
    Two_D_Shapes Two;
    array->area();
    // ---------------------------------------------------------------------------------------------------//
    cirlce c;
    c.getData();
    c.area();
    // ---------------------------------------------------------------------------------------------------//
    square s;
    s.getData();
    s.area();
    // ---------------------------------------------------------------------------------------------------//
    Thr_D_Shapes *T = new cube;
    cube ab;
    ab.getData();
    ab.area();
    T->volume();
    // ---------------------------------------------------------------------------------------------------//
    Thr_D_Shapes *To = new Pyramid;
    T->volume();
    Pyramid p;
    p.getData();
    p.area();
    To->volume();

    return 0;
}

//////////////////////////////////// Question # 01 ////////////////////////////////////
