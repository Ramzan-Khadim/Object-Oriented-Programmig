///////////////////////////////////// Question#03 //////////////////////////////////

#include <iostream>
using namespace std;
class Number
{
private:
	float num;
	float n;
	int result;

public:
	void whole(float n)
	{
		num = n;

		if (num == (int)num)
			cout << "processing......" << endl;
		else
			cout << "Invalid Input";
	}

	void valid_number(float)
	{
		if (num >= 0)
			factorial(num);
		else
			cout << "Invalid Input";
	}

	void factorial(float n)
	{
		int i;
		num = n;
		int fact = 1;
		if (n > 0)
		{
			for (int i = 1; i <= n; ++i)
			{
				fact *= i;
			}
			result = fact;
		}
	}
	void Display()
	{
		cout << "Number    = " << num << endl;
		cout << "Factorial = " << result << endl;
	}
};
int main()
{
	Number n1;
	float x;
	cout << "Enter the number : " << endl;
	cin >> x;
	n1.whole(x);
	n1.valid_number(x);
	n1.factorial(x);
	n1.Display();
	return 0;
}

///////////////////////////////////// Question#03 //////////////////////////////////
