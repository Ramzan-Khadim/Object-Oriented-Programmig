///////////////////////////////////// Question # 01 //////////////////////////////
#include<iostream>
using namespace std;

int main(){

   int year;
   cout <<"Enter the year : ";
   cin >> year;

   if(year%4==0){
   	
       cout << "Enter Year is leep year"<<endl;
   }
   else{

       cout << "Year is not leep year";
}
   return 0;
   
}
/////////////////////////////////////// Question # 01 //////////////////////////////