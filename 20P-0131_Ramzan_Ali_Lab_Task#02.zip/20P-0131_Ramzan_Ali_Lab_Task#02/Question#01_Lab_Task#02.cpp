/////////////////////////////////// Question # 01 ///////////////////////////////////

#include <iostream>

using namespace std;

int main(){
    int x;
    int y;
    cout<<"Enter The first number : "<<endl;
    cin>>x;

    cout<<"Enter The second : "<<endl;
    cin>>y;

    cout<<"Addition of given numbers is : "<<x + y<<endl;		// Addition of 2 numbers
    cout<<"Substraction of given numbers is : "<<x - y<<endl;	// subtraction of 2 numbers
    cout<<"Division of given numbers is : "<< x / y<<endl;		// dividion of 2 numbers
    cout<<"Multiplication of given numbers is : "<< x * y<<endl;	// multiplication 2 numbers
    cout<<"Reminder of given numbers is : "<< x % y<<endl; 		//  reminder of 2 numbers

    return 0;
}
/////////////////////////////////// Question # 01 ///////////////////////////////////
