/////////////////////////////////// Question # 04 ///////////////////////////////////

#include <iostream>

using namespace std;

int main(){

	string full_name;
	cout<<"Enter your full name: "<<endl;
	
	getline(cin,full_name);

	cout<<"Before changing the name: "<<full_name<<endl;

	full_name[4]='_';										//this will change the value of 5th digit of the name
	full_name[9]='_';										//this will change the value of 10th digit of the name	

	cout<<"After changing the name: "<<full_name<<endl;

	return 0;
	
}

/////////////////////////////////// Question # 04 ///////////////////////////////////
