///////////////////////////////////// Qustion # 04 //////////////////////////

#include <iostream>
using namespace std;

int main(){
	
	int n;
	int arr[30];
	cout << "Enter the size of array 0 to 30 : " << endl;
	cin >> n;
	cout << "Enter the element of the array : " << endl;
	for(int i=0; i<n ; i++)
		cin >> arr[i];
	int *max;
	max = arr;
	for(int i=0; i<n ; i++){
		if(*(arr+i) > *max ){
			*max=*(arr+i);
		}	
	}
	cout << "Maximum number in the array is : "<< *max <<endl;
	return 0;
}


//////////////////////////////////// Question # 04 //////////////////////////
