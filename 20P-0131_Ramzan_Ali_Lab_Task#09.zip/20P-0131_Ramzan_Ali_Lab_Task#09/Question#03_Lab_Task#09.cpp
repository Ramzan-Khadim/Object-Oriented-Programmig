/////////////////////////////// Question # 03 //////////////////////////////////

#include <iostream>
using namespace std;
 
class Time {
   private:
      int hours;            
      int minutes;    
	  int second;       
      
   public:

      Time() {
         hours = 0;
         minutes = 0;
		 second=0;
      }
      Time(int h, int m, int s) {
         hours = h;
         minutes = m;
		 second= s;
      }
      

      void display() {
         cout<<hours << " : " << minutes << " : " << second <<endl;
      }        
      // overloaded prefix ++ operator
      Time operator++ () {
		++second;                                         // increment this object
         if(second >= 60) {
            ++minutes;
            second -= 60;
         }
         ++minutes;          
         if(minutes >= 60) {
            ++hours;
            minutes -= 60;
         }
         return Time(hours, minutes,second);
      }
      
                                                        
      Time operator++( int ) {                         // overloaded postfix ++ operator
      

         Time T(hours, minutes, second);
         		++second;                               // increment this object
         if(second >= 60) {
            ++minutes;
            second -= 60;
         }
         ++minutes;                    
         
         if(minutes >= 60) {
            ++hours;
            minutes -= 60;
         }

         return T; 
      }
};

int main() {
   Time T1(11, 57,58), T2(10,28,28);
 cout<<"\n( Prefix Increment )\n";
 cout<<"\nBefore: ";
   ++T1;                                         //PREFIX Increment
   T1.display(); 
   cout<<"\nAfter : ";      
   ++T1;                    
   T1.display();        
 cout<<"\n( Postfix Increment ) \n";
 cout<<"\nBefore: ";
   T2++;                                        // POSTFIX Incriment       
   T2.display();  
cout<<"\nAfter : ";
   T2++;                     
   T2.display();        

   return 0;

}

/////////////////////////////// Question # 03 //////////////////////////////////
