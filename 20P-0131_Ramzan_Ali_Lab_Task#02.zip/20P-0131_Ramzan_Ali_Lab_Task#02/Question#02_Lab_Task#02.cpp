/////////////////////////////////// Question # 02 ///////////////////////////////////
#include <iostream>

using namespace std;

int main(){

    int r;
    float pi = 3.14;						// value of pi

    cout<<"Enter the radius of Sphere : "<<endl;
    cin>>r;									// taking radius from user

    float result = 4 / 3 * pi * r;          // using the formula of volume to take the radius

    cout << "The Volume of sphare of given radius is: " << result << endl;

    return 0;

}
/////////////////////////////////// Question # 02 ///////////////////////////////////
