//////////////////////////////// Question#02 ////////////////////////////////

#include<iostream>
using namespace std;

class brain{

    public:
        int size;
    brain()
    {
        size = 0;
    }

    void setData(int size){
        this->size = size;
    }
    // void abc(){
    //     cout<<"Size of Brain "<<endl;
    // }
    void display(){
        cout << "Brain size is : "<<this->size << endl;
    }

};

class heart{

    public:
        int heart_ratio;

    heart()
    {
        heart_ratio = 0;
    }

    void display(){
        cout <<"Heart BEat Ratio is : "<< this->heart_ratio << endl;
    }
};

class legs{

    public:

    int length;

    legs(){
        length = 0;
    }

    void display(){
        cout <<"Length of Leg is :" <<this->length << endl;
    }
};

class person{
    
    public:

    string prsName;
    brain b;
    heart h;
    legs l;

    public:

    person(){

        prsName = "No Name";
    }


    void display(){
        
        cout<<"Enter Name of Person : ";
        cin>>prsName;
        cout<<"Enter Brain Size of Person : ";
        cin>>b.size;
        cout<<"Enter Heart Beat Ratio  : ";
        cin>>h.heart_ratio;
        cout<<"Enter Length of Legs : ";
        cin>>l.length;
        cout<<"------------------------------------"<<endl;
        cout<<"Name of Person is : "<<prsName<<endl;
        b.display();
        h.display();
        l.display();

    }

};

int main(){

    person p;
    p.b.setData(50);
    p.b.display();
    p.display();
    return 0;

}

//////////////////////////////// Question#02 ////////////////////////////////
