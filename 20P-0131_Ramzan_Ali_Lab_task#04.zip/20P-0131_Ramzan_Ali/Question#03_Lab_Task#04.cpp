#include <iostream>
using namespace std;

int maxfun(int arr[10] ){
	int max = arr [0];	
	for(int i=0 ; i<10 ; i++){	
		if (arr [i] > max ){
			max = arr [i];
		}	
	}
	return max;	
}
int main (){
	
	cout<<"Enter the 10 elements of array : "<<endl;
	int array[10];	
	for(int i =0;i<10 ; i++){
	cin>>array[i];
	}
		
	cout <<"Maximum number in the array is :"<< maxfun(array)<<endl;
return 0;	
}