/////////////////////////////// Question#03//////////////////////////////////
#include <iostream>
using namespace std;
class complex
{
private:
    float x;
    float y;

public:
    void set(float real, float img)
    {
        x = real;
        y = img;
    }
    complex sum(complex);
    void display();
};
complex complex::sum(complex C)
{
    complex k;
    k.x = x + C.x;
    k.y = y + C.y;
    return k;
}
void complex::display()
{
    cout << x << " + "<< y <<"j"<< endl;
}
int main()
{
    complex C1, C2, C3;
    C1.set(2.5, 7.1);
    C2.set(4.2, 5.5);
    C3 = C1.sum(C2);
    cout << "complex Number 1 is = ";
    C1.display();
    cout << "complex Number 2 = ";
    C2.display();
    cout << "Sum of 2 complex numbers is = ";
    C3.display();

    return 0;

}

/////////////////////////////// Question#03//////////////////////////////////
