
//////////////////////////////// Question#01 ////////////////////////////////

#include<iostream>
using namespace std;

class employee{
    
    protected:

    string empName;
    int empNumber;

    public:

    void getData();
    void putData();

    employee(){

        empName = "No Name";
        empNumber = 5 ;
 
    }

    employee(string empName , int empNumber){
        
        this->empName = empName;
        this->empNumber = empNumber;

    }

    void display(){

        cout << empName << endl;
        cout << empNumber << endl;

    }

};

class scientist : public employee{

    private:

    int publication;

    public:

    void getData();
    void putData();

    scientist(string empName , int empNumber, int publication) : employee(empName,empNumber){

        this->publication = publication;

    }
    void display(){

        employee::display();
        cout << this->publication << endl;
        
    }

};

class manager: public employee{

    private:

    char title;
    double club_duse;

    public:

    void getData();
    void putData();

    manager():employee(){

    }
     
    manager(string empName , int empNumber , char title , double club_duse ):employee(empName , empNumber){

        this->title = title;
        this->club_duse = club_duse;

    }
    void display(){

        employee::display();
        cout << this->title << endl;
        cout << this->club_duse << endl;

    }


};

class programmer : public employee{

    private:

    double salary;
    string expertis;

    public:

    void getData();
    void putData();

    programmer(string empName , int empNumber , double salary , string expertis):employee(empName,empNumber){

        this->salary = salary;
        this->expertis = expertis;

    }
    void display(){

        employee::display();
        cout << this->salary << endl;
        cout << this->expertis << endl;
    }


};

int main(){

    manager m;
    m.display();

    programmer p("Raza",5,68000,"Developer");
    p.display();

    return 0;

}

//////////////////////////////// Question#01 ////////////////////////////////
