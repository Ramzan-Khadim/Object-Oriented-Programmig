///////////////////////////////////// Question # 07 //////////////////////////////

#include <iostream>
using namespace std;
struct distance{
 float feet;
 float inches;
};
struct Volume{
 struct distance length;
 struct distance width;
 struct distance height;
 float volume() {
 return (length.feet + length.inches / 12) * (width.feet + width.inches / 12) * (height.feet + height.inches / 12);
 }
};
int main(){
 struct distance length = {5,6}, width = {7,8}, height = {9,10};
 struct Volume Vol;
 Vol.length = length;
 Vol.width = width;
 Vol.height = height;
 cout<<"Volume in cubic feet: "<<Vol.volume();
 return 0;
}

///////////////////////////////////// Question # 07 //////////////////////////////
