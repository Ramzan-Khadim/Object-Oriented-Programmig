#include<iostream>
using namespace std;

class SavingAccount {
    
    private:
    static float annualInterestRate;
    float savingsBalance;
    float monthlyInterest;

    public:
    SavingAccount(float savingsBalance) 
    {
        this->savingsBalance = savingsBalance;

    }

    void calculateMonthlyInterest() 
    {
        this->monthlyInterest = (savingsBalance * annualInterestRate) / 12;
        cout<<"The monthly interest is : " << this->monthlyInterest<<endl;
    }

    static void modifyInterestRate(float interestRate) 
    {
        annualInterestRate = interestRate;
    }

    void calculateSavings() {
        savingsBalance += this->monthlyInterest;
    }

    void displaySavings() {
        cout<<"The total balance is : $ " << savingsBalance<<endl;
    }

};
float SavingAccount::annualInterestRate = 4;
int main(){
    SavingAccount saver1(20000), saver2(30000);
    saver1.calculateMonthlyInterest();
    saver2.calculateMonthlyInterest();
    SavingAccount::modifyInterestRate(4);
    saver1.calculateSavings();
    saver2.calculateSavings();
    saver1.displaySavings();
    saver2.displaySavings();
    return 0;
}
