#include<iostream> 
using namespace std;
class Serial //class declaration
{
       static int number; //variable to store the serial no.
public:
       Serial(); //constructor to set serial number

};
int main()
{
       Serial  s1, s2, s3; // objects
       return 0;
      
}

Serial::Serial()
{
       number++; //++ operator use for increment the value of count
       cout << "I am object with serial number 2022FAST0" << number <<"00P" << endl;
}
int Serial::number = 0; //intialize count to zero