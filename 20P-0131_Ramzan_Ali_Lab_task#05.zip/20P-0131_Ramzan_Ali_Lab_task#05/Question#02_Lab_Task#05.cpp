///////////////////////////////// Question # 02 //////////////////////////

#include <iostream>
using namespace std;

struct point{
	
	int x_coordinate;
	int y_coordinate;
	
};

int main(){
	
	point p1,p2,p3;
	cout << "Enter the x-coordinate of point 1 : ";
	cin>>p1.x_coordinate;
	cout << "Enter the y-coordinate of point 1 : ";	
	cin >> p1.y_coordinate;
	cout << "Enter the x-coordinate of point 2 : ";	
	cin >> p2.x_coordinate;
	cout << "Enter the y-coordinate of point 2 : ";
	cin >> p2.y_coordinate;
	
	p3.x_coordinate = p1.x_coordinate + p2.x_coordinate;
	p3.y_coordinate = p1.y_coordinate + p2.y_coordinate;
	cout << "x-coordinmate of point 3 is : " << p3.x_coordinate << endl;
	cout << "y-coordinmate of point 3 is : " << p3.y_coordinate;
	return 0;
	
}
/////////////////////////////////// Question # 02 //////////////////////////