////////////////////////////////////// Question#02 /////////////////////////////////////

#include <iostream>
using namespace std;
class Laptop
{
private:
	string brand;
	string model;
	string color;
	int serial;
	int ram;
	float price;
	float process_speed;
	float screen_size;

public:
	void set_data(string, string, string);
	void set_Int_data(int, int);
	void set_float_data(float, float, float);
	void ram_upgrade(int);
	void display();
};

int main()
{
	Laptop lap;
	string a, b, c;
	int d, r;
	float e, f, g;
	char option;

	cout << "Enter the Brand : ";
	cin >> a;
	cout << "Enter the  Model : ";
	cin >> b;
	cout << "Enter the color of the laptop : ";
	cin >> c;
	lap.set_data(a, b, c);

	cout << "Enter the Serial of the laptop : ";
	cin >> d;
	cout << "Enter the Ram of the laptop : ";
	cin >> r;
	lap.set_Int_data(d, r);

	cout << "Enter the Price : ";
	cin >> e;
	cout << "Enter the Processor Speed : ";
	cin >> f;
	cout << "Enter the Screen Size of the laptop : ";
	cin >> g;
	lap.set_float_data(e, f, g);

	lap.display();

	while (true)
	{
		cout << "Press 'y' to upgrade the Ram or 'n' to exit : " << endl;
		cin >> option;

		if (option == 'n')
			break;

		else
		{
			cout << "Enter the size of the Additional Ram added to the system : ";
			cin >> r;
			lap.ram_upgrade(r);

			lap.display();
		}
	}

	return 0;
}
void Laptop::set_data(string brd, string mdl, string clr)
{
	brand = brd;
	model = mdl;
	color = clr;
}
void Laptop::set_Int_data(int sr, int r)
{
	serial = sr;
	ram = r;
}
void Laptop::set_float_data(float prc, float cpu, float size)
{
	price = prc;
	process_speed = cpu;
	screen_size = size;
}
void Laptop::ram_upgrade(int r)
{
	ram += r;
}
void Laptop::display()
{
	cout << "Brand         : " << brand << endl;
	cout << "Model         : " << model << endl;
	cout << "Serial        : " << serial << endl;
	cout << "Color         : " << color << endl;
	cout << "Price         : " << price << endl;
	cout << "ProcessorSpeed: " << process_speed << endl;
	cout << "Ram           : " << ram << endl;
	cout << "ScreenSize    : " << screen_size << endl;
	cout << endl;

}

////////////////////////////////////// Question#02 /////////////////////////////////////
