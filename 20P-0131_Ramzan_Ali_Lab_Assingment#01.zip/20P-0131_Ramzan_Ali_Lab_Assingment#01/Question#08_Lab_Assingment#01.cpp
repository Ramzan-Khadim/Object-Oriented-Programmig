///////////////////////////////////// Question # 08 //////////////////////////////

#include<iostream>
#include<conio.h>
#include<stdio.h>
using namespace std;
class batsman
{
	int batcode;
	char batname[20];
	int innings,notout,runs;
	int batavg;
	void calcavg()
	{
		batavg=runs/(innings-notout);
	}
public :
	void readdata ();
	void displaydata();
};
void batsman::readdata ()
{
	cout<<"Enter batsman code: "<<endl;
	cin>> batcode;
	cout<<"Enter batsman name: "<<endl;
	gets(batname);
	cout<<"Enter innings: "<<endl;
	cin>>innings;
	cout<<"Enter notout: "<<endl;
	cin>>notout;
	cout <<"Enter runs: "<<endl;
	cin>>runs;
	calcavg();
}
void batsman::displaydata()
{
	cout<<"Batsman code "<<batcode<<"\nBatsman name "<<batname<<"\nInnings "<<innings
	<<"\nNot out "<<notout<<"\nRuns "<<runs<<"\nBatting Average "<<batavg;
}
int main()
{
	batsman obj;
	obj.readdata();
	obj.displaydata();
	getch();

	return 0;
}

///////////////////////////////////// Question # 08 //////////////////////////////
