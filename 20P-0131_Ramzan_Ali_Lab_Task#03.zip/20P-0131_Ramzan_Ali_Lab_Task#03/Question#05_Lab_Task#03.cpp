//////////////////////////// Question#05 /////////////////////////////////

#include <iostream>
using namespace std;

int main (){
	
	int sallery;
	cout << "Enter the sallary : ";
	cin>>sallery;
	if (sallery<10000){
		
		cout << "There is no deduction "<<endl;
		cout << "Your sallery is :" << sallery;
	}
	else if (sallery>=10000 || sallery > 20000){
		sallery = sallery - 1000;
		cout << "1000 is deducted from your sallery as a fund "<< endl;
		cout <<"Your sallery is : " << sallery ;
		
	}
	else if (sallery >=20000 ){
		sallery =(7/100)*sallery;
		cout << "7% of your sallery is deduct as a fund " << endl;
		cout << "Your sallery is : "<< sallery ;
	}
	return 0;

}

//////////////////////////// Question#05 /////////////////////////////////
