/////////////////////////////// Question # 02 //////////////////////////////////////

#include <iostream>
using namespace std;

class Time {
private:
	int hours, minutes, seconds;

public:

	void set_time(int x, int y, int z)
	{
		hours = x;
		minutes = y;
		seconds = z;
	}

	void display()
	const{                                               //Constant Member Function
		cout << endl
			<< hours << ":" << minutes << ":" << seconds;
	}

	void convert()
	{
		minutes = minutes + seconds / 60;
		seconds = seconds % 60;
		hours = hours + minutes / 60;
		minutes = minutes % 60;
	}

	                                              
	Time operator+(Time t)                          // + Operator overloading to add the time t1 and t2
	{
		Time z;
		z.seconds = seconds + t.seconds;
		z.minutes = minutes + t.minutes;
		z.hours = hours + t.hours;
		z.convert();
		return (z);
	}
};


int main()
{
	Time t1, t2, t3;                          // creating objects
	t1.set_time(5, 50, 30);
	t2.set_time(7, 20, 34);

	
	t3 = t1 + t2;                            // Operator overloading

	t1.display();
	t2.display();
	t3.display();

	return 0;

}

////////////////////////////// Question # 02 //////////////////////////////////////
