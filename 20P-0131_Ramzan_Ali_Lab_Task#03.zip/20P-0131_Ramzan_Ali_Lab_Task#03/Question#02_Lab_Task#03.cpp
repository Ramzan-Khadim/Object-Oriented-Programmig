//////////////////////////////// Question # 02 ////////////////////////////////

#include <iostream>
using namespace std;

int main(){

	float n1, n2, result;
	char opr, ch;
	do
	{
		cout << "Enter first number, opr, and Enter second number: ";
		cin >> n1 >> opr >> n2;
		switch (opr)
		{
		case '+':
			result = n1 + n2;
			break;
		case '-':
			result = n1 - n2;
			break;
		case '*':
			result = n1 * n2;
			break;
		case '/':
			result = n1 / n2;
			break;
		default:
			cout << "The given opr is invalid ";
		}
		cout << "Answer = " << result;
		cout << "\nDo another(Enter 'y' or 'n')? ";
		cin >> ch;
	} while (ch != 'n');
	return 0;
}

//////////////////////////////// Question # 02 ////////////////////////////////
