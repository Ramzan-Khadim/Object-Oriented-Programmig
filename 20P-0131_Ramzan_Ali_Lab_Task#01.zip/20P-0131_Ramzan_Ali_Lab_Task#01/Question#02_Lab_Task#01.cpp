///////////////////////////////////// Question #02 ///////////////////////////////////////

#include <iostream>
using namespace std;

int main()
{
	char c;
	cout << "Enter a character: " << endl;
	cin >> c;
	cout << "ASCII Value of given Character : " << c << " is " << int(c);
	return 0;
}
///////////////////////////////////// Question #02 ///////////////////////////////////////