///////////////////////////////////// Question # 04 //////////////////////////////

#include<iostream>
using namespace std;
int* arrayFunction(int n)
{
    int* arr=new int[n];
    cout<<"Elements of array : "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    return arr;
}
int main()
{
    int n;
    cout<<"Elements in the array : ";
    cin>>n;
    int* ar=arrayFunction(n);
    cout<<"Elements of array are : "<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<ar[i]<<" ";
    }
}

///////////////////////////////////// Question # 04 //////////////////////////////
