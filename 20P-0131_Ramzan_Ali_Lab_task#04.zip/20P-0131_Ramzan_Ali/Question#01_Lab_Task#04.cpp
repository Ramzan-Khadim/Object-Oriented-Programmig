#include <iostream>
using namespace std;

void Factorial(){
	
	int  n ;
	cout<<"Enter a Number for factorial : ";
    cin>>n;
	
	int factorial = 1;
    for (int i = 1; i <= n; ++i) {
        factorial = factorial * i;
    }
    cout<< "Factorial of given Number "<<n<<" is "<<" = "<<factorial;    
}
int main() {
   
	Factorial();
	
	return 0;
}
