//////////////////////////// Question#01////////////////////////////////
#include <iostream>
using namespace std;
int main(){

    int num;
    cout << "Pleas Enter The Number : ";
    cin >> num;
    int count = 1;

    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            cout << num * count << "\t";
            count++;
        }
        cout << endl;
    }

    return 0;
}

//////////////////////////// Question#01////////////////////////////////
