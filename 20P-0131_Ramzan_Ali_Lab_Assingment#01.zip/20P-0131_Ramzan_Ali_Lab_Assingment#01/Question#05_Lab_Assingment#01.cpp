///////////////////////////////////// Question # 05 //////////////////////////////

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
	int number, guess, atempts = 0;
	number = rand() % 100 ; 
	cout << "Guess My Random Number "<<endl;

	do
	{
		cout << "Enter a guess between 1 and 100 : ";
		cin >> guess;
		atempts++;

		if (guess > number)
			cout << "Your number is high! please try again..."<<endl;
		else if (guess < number)
			cout << "Your number is too low! please try again..."<<endl;
		else
			cout << "You found random number in " << atempts << " Attempts!"<<endl;
			
	} while (guess != number);                             
		
	return 0;

}

///////////////////////////////////// Question # 05 //////////////////////////////

