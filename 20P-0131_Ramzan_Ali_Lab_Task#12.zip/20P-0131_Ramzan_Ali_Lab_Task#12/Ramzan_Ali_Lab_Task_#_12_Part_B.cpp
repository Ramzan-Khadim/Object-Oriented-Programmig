////////////////////////// Ramzan_Ali_Lab_Task_#_12_Part_B //////////////////////////

#include <iostream>
using namespace std;

const int MAX_CHECKS = 5;
const double SVC_CHARGE = 10.0;

////////////////////////////// Class Bank Account //////////////////////////////

class BankAccount
{
protected:
    string Name;
    int AcctNumber;
    double Balance;

public:
    virtual void withdraw(double amount) = 0;
    virtual void printStatement() = 0;

    void make_deposit(double amount)
    {

        Balance += amount;
        cout << "$" << amount << " has been deposited to your account" << endl;
    }

    BankAccount(int acctNum, string name, double initialBalance)
    {
        AcctNumber = acctNum;
        Name = name;
        Balance = initialBalance;
    }

    string get_Name()
    {
        return Name;
    }
    int get_AcctNumber()
    {
        return AcctNumber;
    }
    double get_Balance()
    {
        return Balance;
    }

    virtual void printSummary()
    {
        cout << endl;
        cout << "Account Summary" << endl;
        cout << endl;
        cout << "Name: " << Name << endl;
        cout << "Account #: " << AcctNumber << endl;
        cout << "Current Balance: $" << Balance << endl;
    }
    ~BankAccount(void) {}
};

////////////////////////////// Class Saving Account //////////////////////////////

class savingsAccount : public BankAccount
{
protected:
    double m_InterestRate;

public:
    savingsAccount(int acctNum, string name, double initialBalance) : BankAccount(acctNum, name, initialBalance)
    {
        m_InterestRate = 3.99;
    }
    ~savingsAccount(void)
    {
    }
    void withdraw(double amount)
    {
        if (Balance - amount < 0)
        {
            cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
            return;
        }
        Balance -= amount;
    }
    void printSummary()
    {
        BankAccount::printSummary();
        cout << "Interest rate: " << m_InterestRate << "%" << endl;
    }
    void printStatement()
    {
        printSummary();
        cout << "A full implementation would also print a Savings Account Statement here." << endl;
    }
};

////////////////////////////// Class High interest Rate //////////////////////////////

class highInterestSavings : public savingsAccount
{

protected:
    double m_MinimumBalance;

public:
    highInterestSavings(int acctNum, string name, double initialBalance) : savingsAccount(acctNum, name, initialBalance)
    {
        m_MinimumBalance = 5000;
    }
    ~highInterestSavings(void) {}
    void withdraw(double amount)
    {
        if (Balance - amount < 0)
        {
            cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
            return;
        }
        if (Balance - amount < m_MinimumBalance)
        {
            cout << "Declined: Minimum balance requirement prohibits this withdrawal" << endl;
            return;
        }
        Balance -= amount;
    }
    void printSummary()
    {
        BankAccount::printSummary();

        cout << "Interest rate: " << m_InterestRate << "%" << endl;
        cout << "Minimum Balance: $" << m_MinimumBalance << endl;
    }
};

////////////////////////////// Class Checking Account //////////////////////////////

class checkingsAccount : public BankAccount
{
public:
    double m_InterestRate;
    int m_ChecksRemaining;
    double m_MinimumBalance;
    virtual void writeCheck(double amount) = 0;
    checkingsAccount(int acctNum, string name, double initialBalance) : BankAccount(acctNum, name, initialBalance)
    {
    }
    void withdraw(double amount)
    {
        if (Balance - amount < 0)
        {
            cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
            return;
        }
        if (Balance - amount < m_MinimumBalance)
        {
            cout << "Declined: Minimum balance requirement prohibits this withdrawal" << endl;
            return;
        }
        Balance -= amount;
    }
    void printStatement()
    {
        printSummary();
        cout << endl;
        cout << "A full implementation would also print details of a Checking Account Statement here." << endl;
        cout << endl;
    }
    //  ~checkingAccount(void) {}
};

////////////////////////////// Class Service Charging Checking //////////////////////////////

class serviceChargeChecking : public checkingsAccount
{
public:
    serviceChargeChecking(int acctNum, string name, double initialBalance) : checkingsAccount(acctNum, name, initialBalance)
    {
        m_InterestRate = 0;             // No interest
        m_ChecksRemaining = MAX_CHECKS; // Limit of 5 checks
        m_MinimumBalance = 0;           // No minimum balance
    }
    ~serviceChargeChecking(void) {}
    void writeCheck(double amount)
    {
        if (m_ChecksRemaining == 0)
        {
            cout << "Declined: No more checks remaining this month" << endl;
            return;
        }
        if (Balance - amount < 0)
        {
            cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
            return;
        }
        m_ChecksRemaining--;
        Balance -= amount;
    }
    void printSummary()
    {
        BankAccount::printSummary();
        cout << "Checks remaining: " << m_ChecksRemaining << endl;
        cout << "Monthly service fee: $" << SVC_CHARGE << endl;
        cout << "No interest " << endl;
        cout << "No Minimum Balance " << endl;
    }
};

////////////////////////////// Class No Service Charging Checking //////////////////////////////

class noServiceChargeChecking : public checkingsAccount
{
public:
    noServiceChargeChecking(int acctNum, string name, double initialBalance) : checkingsAccount(acctNum, name, initialBalance)
    {
        m_InterestRate = 2.5;
        m_ChecksRemaining = -1;
        m_MinimumBalance = 500;
    }
    ~noServiceChargeChecking(void) {}
    void writeCheck(double amount)
    {
        if (Balance - amount < 0)
        {
            cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
            return;
        }
        Balance -= amount;
    }
    void printSummary()
    {
        BankAccount::printSummary();

        cout << "Interest rate: " << m_InterestRate << "%" << endl;
        cout << "Minimum Balance: $" << m_MinimumBalance << endl;
        cout << "Unlimited checks   " << endl;
        cout << "No monthly service fee   " << endl;
    }
};

////////////////////////////// Class High interest Checking //////////////////////////////

class highInterestChecking : public noServiceChargeChecking
{
public:
    highInterestChecking(int acctNum, string name, double initialBalance) : noServiceChargeChecking(acctNum, name, initialBalance)
    {
        m_InterestRate = 5.0;
        m_ChecksRemaining = -1;
        m_MinimumBalance = 1000;
    }
    ~highInterestChecking(void) {}
};

////////////////////////////// Class certificateOfDeposit //////////////////////////////

class certificateOfDeposit : public BankAccount
{
private:
    double m_InterestRate;
    int m_MaturityMonths;
    int m_CurrentMonth;

public:
    certificateOfDeposit(int acctNum, string name, double initialBalance, int matMon) : BankAccount(acctNum, name, initialBalance)
    {
        m_MaturityMonths = matMon;
        m_CurrentMonth = 1;
        m_InterestRate = 4.75;
    }

    void withdraw(double amount)
    {
        if (Balance - amount < 0)
        {
            cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
            return;
        }
        Balance -= amount;
    }
    void printSummary()
    {
        BankAccount::printSummary();
        cout << "Interest rate: " << m_InterestRate << "%" << endl;
        cout << "Maturity Months: " << m_MaturityMonths << endl;
        cout << "Current Month: " << m_CurrentMonth << endl;
        cout << endl;
    }
    void printStatement()
    {
        printSummary();
        cout << "A full implementation would also print a Certificate of Deposite Account Statement here." << endl;
    }

    ~certificateOfDeposit(void) {}
};

////////////////////////////// Tests For Classes //////////////////////////////

///////////////////////// Tests For CertificateOfDeposit //////////////////////

void TestCertificateOfDeposit()
{
    certificateOfDeposit acct(123, "Ramzan Ali", 10000, 6);
    char input = 0;
    double amount;
    cout << "Testing High Interest Savings" << endl;
    cout << "Current account overview:" << endl;
    acct.printSummary();
    cout << endl;
    while (input != 'x')
    {
        cout << "Select a transaction:" << endl;
        cout << "1 - Make a Withdrawal" << endl;
        cout << "2 - Make a Deposit" << endl;
        cout << "3 - Print Summary" << endl;
        cout << "4 - Print Monthly Statement" << endl;
        cout << "x - Exit Test Suite" << endl;
        cout << "Enter choice: ";
        cin >> input;
        switch (input)
        {
        case '1':
            cout << "Enter amount: ";
            cin >> amount;
            acct.withdraw(amount);
            break;
        case '2':
            cout << "Enter amount: ";
            cin >> amount;
            acct.make_deposit(amount);
            break;
        case '3':
            acct.printSummary();
            break;
        case '4':
            acct.printStatement();
            break;
        case 'x':
            break;
        default:
            cout << "Invalid choice" << endl;
            break;
        }
        acct.printSummary();
        cout << endl;
    }
}

///////////////////////////// Tests For Savings //////////////////////////////

void TestSavings()
{
    savingsAccount acct(123, "Ramzan Ali", 1000);
    char input = 0;
    double amount;
    cout << "Testing Regular Savings" << endl;
    cout << "Current account overview:" << endl;
    acct.printSummary();
    cout << endl;
    while (input != 'x')
    {
        cout << "Select a transaction:" << endl;
        cout << "1 - Make a Withdrawal" << endl;
        cout << "2 - Make a Deposit" << endl;
        cout << "3 - Print Summary" << endl;
        cout << "4 - Print Monthly Statement" << endl;
        cout << "x - Exit Test Suite" << endl;
        cout << "Enter the amount:" << endl;
        cin >> input;
        switch (input)
        {
        case '1':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.withdraw(amount);
            break;
        case '2':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.make_deposit(amount);
            break;
        case '3':
            acct.printSummary();
            break;
        case '4':
            acct.printStatement();
            break;
        case 'x':
            break;
        default:
            cout << "Invalid choice" << endl;
            break;
        }
        acct.printSummary();
        cout << endl;
    }
}

///////////////////////////// Tests For CheckingWithService //////////////////////////////

void TestCheckingWithService()
{
    serviceChargeChecking acct(123, "Ramzan Ali", 5000);
    char input = 0;
    double amount;
    cout << " The Testing Checking with Service Charge" << endl;
    cout << "Current account overview:" << endl;
    acct.printSummary();
    cout << endl;
    while (input != 'x')
    {
        cout << "Select a transaction:" << endl;
        cout << "1 - Make a Withdrawal" << endl;
        cout << "2 - Make a Deposit" << endl;
        cout << "3 - Print Summary" << endl;
        cout << "4 - Print Monthly Statement" << endl;
        cout << "5 - Write a check" << endl;
        cout << "x - Exit Test Suite" << endl;
        cout << "Enter choice: ";
        cin >> input;
        switch (input)
        {
        case '1':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.withdraw(amount);
            break;
        case '2':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.make_deposit(amount);
            break;
        case '3':
            acct.printSummary();
            break;
        case '4':
            acct.printStatement();
            break;
        case '5':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.writeCheck(amount);
            break;
        case '6':
            break;
        case 'x':
            break;
        default:
            cout << "Invalid choice" << endl;
            break;
        }
        acct.printSummary();
        cout << endl;
    }
}

///////////////////////////// Tests For CheckingNoService //////////////////////////////

void TestCheckingNoService()
{
    noServiceChargeChecking acct(123, "Ramzan Ali", 5000);
    char input = 0;
    double amount;
    cout << "Testing Checking without Service Charge" << endl;
    cout << "Current account overview:" << endl;
    acct.printSummary();
    cout << endl;
    while (input != 'x')
    {
        cout << "Select a transaction:" << endl;
        cout << "1 - Make a Withdrawal" << endl;
        cout << "2 - Make a Deposit" << endl;
        cout << "3 - Print Summary" << endl;
        cout << "4 - Print Monthly Statement" << endl;
        cout << "5 - Write a check" << endl;
        cout << "x - Exit Test Suite" << endl;
        cout << "Enter choice: ";
        cin >> input;
        switch (input)
        {
        case '1':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.withdraw(amount);
            break;
        case '2':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.make_deposit(amount);
            break;
        case '3':
            acct.printSummary();
            break;
        case '4':
            acct.printStatement();
            break;
        case '5':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.writeCheck(amount);
            break;
        case '6':
            break;
        case 'x':
            break;
        default:
            cout << "Invalid choice" << endl;
            break;
        }
        acct.printSummary();
        cout << endl;
    }
}

///////////////////////////// Tests For CheckingHighInterest //////////////////////////////

void TestCheckingHighInterest()
{
    highInterestChecking acct(123, "Ramzan Ali", 5000);
    char input = 0;
    double amount;
    cout << "\t\tTesting Checking with High Interest" << endl
         << endl;
    cout << "Current account overview:" << endl;
    acct.printSummary();
    cout << endl;
    while (input != 'x')
    {
        cout << "Select a transaction:" << endl;
        cout << "1 - Make a Withdrawal" << endl;
        cout << "2 - Make a Deposit" << endl;
        cout << "3 - Print Summary" << endl;
        cout << "4 - Print Monthly Statement" << endl;
        cout << "5 - Write a check" << endl;
        cout << "x - Exit Test Suite" << endl;
        cout << "Enter choice: ";
        cin >> input;
        switch (input)
        {
        case '1':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.withdraw(amount);
            break;
        case '2':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.make_deposit(amount);
            break;
        case '3':
            acct.printSummary();
            break;
        case '4':
            acct.printStatement();
            break;
        case '5':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.writeCheck(amount);
            break;
        case '6':
            break;
        case 'x':
            break;
        default:
            cout << "Invalid choice" << endl;
            break;
        }
        acct.printSummary();
        cout << endl;
    }
}

///////////////////////////// Tests For SavingsHighInterest //////////////////////////////

void TestSavingsHighInterest()
{
    highInterestSavings acct(123, "Ramzan Ali", 8000);
    char input = 0;
    double amount;
    cout << "Testing High Interest Savings" << endl;
    cout << "Current account overview:" << endl;
    acct.printSummary();
    cout << endl;
    while (input != 'x')
    {
        cout << "Select a transaction:" << endl;
        cout << "1 - Make a Withdrawal" << endl;
        cout << "2 - Make a Deposit" << endl;
        cout << "3 - Print Summary" << endl;
        cout << "4 - Print Monthly Statement" << endl;
        cout << "x - Exit Test Suite" << endl;
        cout << "Enter the amount:" << endl;
        cin >> input;
        switch (input)
        {
        case '1':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.withdraw(amount);
            break;
        case '2':
            cout << "Enter the amount:" << endl;
            cin >> amount;
            acct.make_deposit(amount);
            break;
        case '3':
            acct.printSummary();
            break;
        case '4':
            acct.printStatement();
            break;
        case 'x':
            break;
        default:
            cout << "Invalid choice" << endl;
            break;
        }
        acct.printSummary();
        cout << endl;
    }
}

////////////////////////////// Main Function //////////////////////////////////

int main()
{
    char input;
    cout << "Welcome to the Bank Account " << endl;
    cout << "What type of account do you want to test?" << endl;
    cout << "1 - Checking with Service Charge" << endl;
    cout << "2 - Checking without Service Charge" << endl;
    cout << "3 - Checking with High Interest" << endl;
    cout << "4 - Savings" << endl;
    cout << "5 - Savings with High Interest" << endl;
    cout << "6 - Certificate of Deposit" << endl;
    cout << "Enter choice: ";
    cin >> input;
    switch (input)
    {
    case '1':
        TestCheckingWithService();
        break;
    case '2':
        TestCheckingNoService();
        break;
    case '3':
        TestCheckingHighInterest();
        break;
    case '4':
        TestSavings();
        break;
    case '5':
        TestSavingsHighInterest();
        break;
    case '6':
        TestCertificateOfDeposit();
        break;
    default:
        cout << "Invalid choice" << endl;
        break;
    }

    return 0;
}

////////////////////////////// Ramzan_Ali_Lab_Task_#_12_Part_B //////////////////////////////
