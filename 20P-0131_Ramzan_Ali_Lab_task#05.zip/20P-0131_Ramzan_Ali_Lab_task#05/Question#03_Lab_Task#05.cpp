///////////////////////////////////// Question # 03 /////////////////////////

#include <iostream>
using namespace std;


int main(){
	
	int a;
	int b;
	int *ptrA;
	int *ptrB;
	ptrA = &a;
	ptrB = &b;
	cout << "Enter the first integer : ";
	cin >> a;
	cout << "Enter the second integer : ";
	cin >> b;
	cout <<"first integer was : "<<*ptrA << endl;
	cout <<"second integer was : "<<*ptrB << endl;	
	return 0;
	
}
///////////////////////////////////// Question # 03 /////////////////////////