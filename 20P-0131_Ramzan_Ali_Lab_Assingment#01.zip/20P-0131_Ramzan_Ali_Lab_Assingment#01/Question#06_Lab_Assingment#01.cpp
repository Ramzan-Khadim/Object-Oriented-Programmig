///////////////////////////////////// Question # 06 //////////////////////////////

#include <iostream>
#include<conio.h>
using namespace std;

int main() {

   char string[20], *ptr;
   int i = 0;
   cout << "Enter the string:"<<endl;
   cin>>string;

   ptr = string;
   while (*ptr != '\0') {
      i++;
      ptr++;
   }
   cout << "Length of given String is : " << i;

   return 0;

}

///////////////////////////////////// Question # 06 //////////////////////////////
