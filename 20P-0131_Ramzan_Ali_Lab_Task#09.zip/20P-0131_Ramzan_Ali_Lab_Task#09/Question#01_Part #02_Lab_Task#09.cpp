/////////////////////////////////// Question # 01 B //////////////////////////////////

#include <iostream>
#include <string.h>
using namespace std;

class serial_number
{
	private:
		char str[30];                                  			//Private variables 
		static int count;
		
	public:

		serial_number()
		{
			count++;
		}

		void initial_srlN(char s[])                    //Member functions
		{
			strcpy(str,s);
		}

		void display(void)                        //Constant Member functions
		const{
			cout << "I'm object with Serial Number:  " << str << endl;
		}

		static int T_ob(void)
		{
			return count;
		}
};

int serial_number::count =0;

int main()
{
	 serial_number ob1;
	 serial_number ob2;
	 serial_number ob3;
	
	 ob1.initial_srlN("2022FAST01OOP");
	 ob2.initial_srlN("2022FAST02OOP");  			 // Constant member function arguments
	 ob3.initial_srlN("2022FAST03OOP");
	
	ob1.display();
	ob2.display();
	ob3.display();

	cout << "\nTotal objects created: " << serial_number::T_ob() << endl;
	
	return 0;
}

/////////////////////////////////// Question # 01 B //////////////////////////////////