/////////////////////////////////// Question # 01 A ///////////////////////////////////

#include <iostream>
using namespace std;

class tollboth
{
    private:
    static int car;
    int pay;

    public:

    void paid_car(){
        car++;
        pay+=50;
        cout<< "paid car added successfully"<<endl;
        
    }

    void un_paid_car()const{                                        //Constant Member Function
        car++;
        cout<< "unpaid car added successfully"<<endl;
    }

    void display()const{                                     //Constant Member Function
        cout<<"Total cars: "<<car<<endl;
        cout<<"Total payment: "<<pay<<endl;

    }

};  

int tollboth:: car=0;

int main(){
    tollboth a;
    int i;
    char c;

    again:
cout<<"1. Piad Cars\n2. Non-paid Cars\n3. Total Cars Or payment\n";
cin>>i;
    if(i==1)
    {
       a.paid_car();
    }
    else if(i==2)
    {
         a.un_paid_car();
    }
    else if(i==3)
    {
         a.display();
    }
    else
    {
    cout<<"Inavlid input"<<endl;
    goto again;
    }
    cout<<"Do you want add more Y/N:";
    cin>>c;
    if (c=='Y'|| c=='y' ){
        goto again;
    }

    return 0;
    
}

/////////////////////////////////// Question # 01 A ///////////////////////////////////