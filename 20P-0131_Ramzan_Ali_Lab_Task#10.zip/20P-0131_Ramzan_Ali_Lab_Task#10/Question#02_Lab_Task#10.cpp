#include <iostream>
using namespace std;
class Item{
 	protected:
 		int id_i;
 		string name_i;
 		float price_i;
 		public:
 		Item (){
 		    id_i=0;
 		    name_i="no name";
 		    price_i=0.0;
 		    
 		}
 		Item (int a ,string b,float c){
 		    id_i=a;
 		    name_i=b;
 		    price_i=c;
 		    
 		}
 		void new_i(){
 		    cout<<"enter new item id no"<<endl;
 		    cin>>id_i;
 		    cout<<"enter the name of new product"<<endl;
 		    cin>>name_i;
 		    cout<<"enter the price"<<endl;
 		    cin>>price_i;
 		}
 		void update_i(){
 		    cout<<"please enter the id no of product"<<endl;
 		    int id;
 		    cin>>id;
 		    if(id==id_i){
 		        cout<<"Enter the new price of this product"<<endl;
 		        cin>>price_i;
 		    }
 		}
 		void print(){
 		    cout<<"Product id no i s: "<<id_i<<endl;
 		    cout<<"product name is : "<<name_i<<endl;
 		    cout<<"price of product is : "<<price_i<<endl;
 		}
}; 		
class employee:public Item{
 	private:
	int id;
 	string name;
 	string password;
 	public:
 	employee(){
 	    id=0;
 	    name="no name";
 	    password="**";
 	}
 	employee(int e,string n,string p){
 	    id=e;
 	    name=n;
 	    password=p;
 	}
 	void new_it(){
 	    cout<<"To Add new item enter your id no : "<<endl;
 	    cin>>id;
 	    cout<<"enter your name : "<<endl;
 	    cin>>name;
 	    cout<<"enter password: "<<endl;
 	    cin>>password;
 	    Item:: new_i();
 	}
 	void update(){
 	    cout<<"To Update  item enter your id no : "<<endl;
 	    cin>>id;
 	    cout<<"enter your name : "<<endl;
 	    cin>>name;
 	    cout<<"enter password : "<<endl;
 	    cin>>password;
 	    Item::update_i();
 	}
 	void print (){
 	    Item::print();
 	    cout<<"employee id no is : "<<id<<endl;
 	    cout<<"employee name is  : "<<name<<endl;
 	}
}; 	
int main()
{
    Item i;
    i.new_i();
    i.update_i();
    i.print();
    employee e,e1(1,"Raza_Baqir ","password");
    e1.print();
    e.new_it();
    e.print();
    e.update();
    e.print();

    return 0;
}