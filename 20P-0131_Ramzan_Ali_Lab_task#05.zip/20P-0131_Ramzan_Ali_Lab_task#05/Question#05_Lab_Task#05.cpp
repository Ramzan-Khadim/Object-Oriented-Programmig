//////////////////////////////////// Question # 05 //////////////////////////

#include <iostream>
using namespace std;

int main(){
	
	int a ;
	cout << "Enter the any number: "; 
	cin >> a ;
	cout << "We enter : " << a<<endl;
	int *ptr;
	ptr = &a;
	
	cout << "Value by pointer is : "<< *ptr << endl; 
	cout<< "memory adress of number is : "<< ptr ;
	return 0;
}

////////////////////////////////////// Question # 05 //////////////////////////
