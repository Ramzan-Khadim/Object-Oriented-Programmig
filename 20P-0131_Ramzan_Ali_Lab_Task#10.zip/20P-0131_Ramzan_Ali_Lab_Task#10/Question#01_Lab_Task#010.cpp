#include<iostream>
using namespace std;

class Human{
    protected:
    string name;
    int age;
    public:
    Human(){
        name = "";
        age = 0;
    }
    Human(string name, int age){
 
        this->name = name;
        this->age = age;   
    }
    void print(){
        cout << name << " " ;
        cout << age ;
    }
};
class Student : public Human{
    public:
    float gpa;
    public:
    Student(): Human(){
      
        this->gpa = 0;
    }
    Student(string name, int age , float gpa) : Human(name,age){

        this->gpa = gpa;
    }
    void print(){
        Human::print();
        cout << " " <<this->gpa << endl;
    }
};

int main(){

    Student s1("Raza_Baqir",22,2.6);
    cout << endl;
    s1.print();

    return 0;

}