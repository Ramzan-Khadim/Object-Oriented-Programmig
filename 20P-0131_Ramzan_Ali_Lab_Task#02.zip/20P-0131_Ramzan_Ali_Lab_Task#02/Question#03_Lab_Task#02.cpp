/////////////////////////////////// Question # 03 ///////////////////////////////////

#include <iostream>

using namespace std;

int main(){

	int x;
	cout<<"Enter five numbers of your choice : "<<endl;

	cin>>x;
	cout<<"Before changing the numbers: "<<x<<endl;

	double b;
	double y;
	double z;

	b = x % 10; 	//by taking modulus by 10 out of 5 digit number the last number will store in b
	x = x / 10;		//by dividing x by 10 4 digits will store in x because x is integer variable
	y = x % 10;		//by taking modulus again by 10 out of 4 digit number now the last number will store in y
	x = x / 10;		//by dividing x by 10 3 digits will store in a because x is integer variable
	z = x % 10;		//by taking modulus again by 10 out of 3 digit number now the last number will store in y
	
	cout<<"After changing the numbers are: "<<b<<y<<x;	
	
	return 0;

}

/////////////////////////////////// Question # 03 ///////////////////////////////////