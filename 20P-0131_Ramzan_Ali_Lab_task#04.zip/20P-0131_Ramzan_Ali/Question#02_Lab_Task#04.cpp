#include <iostream>
using namespace std;

void pass_by_value(int num1){
	
	num1 = num1*num1*num1;
	cout << num1 <<endl;
}
int pass_by_referance(int &num2){

	return num2 = num2*num2*num2;
}
int main (){	

	int num1;
	int num2;
	cout<<"Enter the first number : ";
	cin>> num1;
	cout <<"Enter the second number : ";
	cin >> num2;
	cout << "Pass by value result : ";
	pass_by_value(num1);
	cout << "Pass by referance result : ";
    int x = pass_by_referance(num2);
	cout << x << endl;
	cout << "num1 : " <<num1<< endl;
	cout <<"num2 : "<< num2 << endl;

	return 0;	
}