//////////////////////////////////// Question#01 /////////////////////////////////////////

#include <iostream>
#include <string.h>
using namespace std;

class tollBooth
{
public:
	int cars, cash;
	tollBooth()
	{
		cars = 0;
		cash = 0;
	}
	void paying_car()
	{
		cout << "Enter the amount of toll:";
		cin >> cash;
		cash = cash++;
		cars++;
	}
	void npaying_car()
	{
		cars++;
	}
	void display()
	{
		cout << "information about the tollbooth" << endl;
		cout << "Tollamount      passing cars" << endl;
		cout << "  " << cash << "              " << cars << endl;
	}
};
int main()
{
	tollBooth c1;
	int num;
	char cha = 'y';
	while (cha == 'y')
	{
		cout << "Enter the information about the toolbooth" << endl;
		cout << "1.for paying cars:" << endl;
		cout << "2.for non paying cars:" << endl;
		cout << "3.for display the collected information:" << endl;
		cout << "4.for exit" << endl;
		cin >> num;
		switch (num)
		{
		case 1:
			c1.paying_car();
			break;
		case 2:
			c1.npaying_car();
			break;
		case 3:
			c1.display();
			break;
		}
		cout << "Want to perform more oprations(y/n)?";
		cin >> cha;
	}
	return 0;

}

//////////////////////////////////// Question#01 /////////////////////////////////////////
