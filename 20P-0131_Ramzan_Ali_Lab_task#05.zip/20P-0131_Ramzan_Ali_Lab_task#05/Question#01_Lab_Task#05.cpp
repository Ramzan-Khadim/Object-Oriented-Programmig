///////////////////////// Question # 01 //////////////////////

#include <iostream>
using namespace std;

struct time{
	int hours;
	int minuts;
	int seconds;
};

int seconds(time t){
	cout << "Totel seconds are : ";
	int x = t.hours*60*60;
	int y = t.minuts*60;
	int z = t.seconds;
	return x+y+z;
}	
int main(){
	time t;
    cout << "Enter the hours : ";
	cin >> t.hours;
	cout << "Enter the minuts : ";
	cin >> t.minuts;
	cout << "Enter the seconds: ";
	cin >> t.seconds;
	cout << seconds(t);
	return 0;
}

/////////////////////////////// Question # 01 //////////////////////////