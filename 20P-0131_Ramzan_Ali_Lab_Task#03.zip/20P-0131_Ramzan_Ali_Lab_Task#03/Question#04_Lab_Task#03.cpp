//////////////////////////////// Question#04 ////////////////////////////////

#include <iostream>
using namespace std;

int main(){

	int x = 5, y = 10, z = 15;
	cout << endl;
	cout << "Anewers would be following.... " << endl;

	cout << !(x < 10) << endl;
	cout << (x <= 5 || y < 15) << endl;
	cout << ((x != 5) && (y != z)) << endl;
	cout << ((x >= z) || (x + y >= z)) << endl;
	cout << ((x <= y - 2) && (y >= z) || (z - 2 != 20)) << endl;

	return 0;
}

//////////////////////////////// Question#04 ////////////////////////////////
