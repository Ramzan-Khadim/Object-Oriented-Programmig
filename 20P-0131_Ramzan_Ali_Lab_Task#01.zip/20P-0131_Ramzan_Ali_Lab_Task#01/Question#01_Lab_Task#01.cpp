///////////////////////////////////// Question #01 ///////////////////////////////////////

#include <iostream>
using namespace std;

int main()
{
	int a;
	char b;
	float c;
	long d;
	double e;

	// Size of Variables
	cout << "Size of int is : " << sizeof(a) << " Bytes" << endl;
	cout << "Size of char is : " << sizeof(b) << " Byte" << endl;
	cout << "Size of float is : " << sizeof(c) << " Bytes" << endl;
	cout << "Size of long is : " << sizeof(d) << " Bytes" << endl;
	cout << "Size of double is : " << sizeof(e) << " Bytes" << endl;

	return 0;
}

///////////////////////////////////// Question #01 ///////////////////////////////////////