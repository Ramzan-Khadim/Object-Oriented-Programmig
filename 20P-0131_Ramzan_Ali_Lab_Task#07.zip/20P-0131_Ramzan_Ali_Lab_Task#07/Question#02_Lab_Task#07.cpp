///////////////////////////////// Question # 02 /////////////////////////////////

#include<iostream>
#include <iomanip>
using namespace std;

class Time {
private:
    int hrs;
    int min;
    int sec;
public:
    Time(){                        
       hrs = 0;
       min = 0;
       sec = 0;
   }
    Time(int h, int m, int s) {       
        hrs = h;
        min = m;
        sec = s;
   }
    void show(){
        cout << setw(2)<<setfill('0')<< hrs << ":" << setw(2)<<setfill('0')<< min << ":" << setw(2)<<setfill('0')<< sec << endl;
}  
    void sum(Time a, Time b) {
        int x=0;
        sec = a.sec + b.sec;
         if(sec > 59){
            sec = sec-60;
            x++;
       }  
       min = a.min + b.min+x;
       x=0;
       if(min > 59){
          min-=60;
          x++;
       }
          hrs = a.hrs + b.hrs+x;
       if(hrs >= 24)
          hrs-=24;
   }    
};

int main() {
Time T1(5, 6, 58);
Time T2(7, 58, 3);
Time T3(0, 0, 0);

cout<<"T1 Time : ";
T1.show();

cout<<"T2 Time : ";
T2.show();

cout<<"Sum of Time 1 and Time 2 is : ";
T3.sum(T1, T2);
T3.show();

return 0;

}

///////////////////////////////// Question # 02 /////////////////////////////////
